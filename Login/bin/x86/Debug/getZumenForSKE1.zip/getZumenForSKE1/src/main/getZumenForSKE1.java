package main;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.Properties;

public class getZumenForSKE1 {

	// DBの接続設定(
	private static Connection con = null;
	private PreparedStatement[] pstmt = new PreparedStatement[5];

	protected static String enCode; // ファイルエンコード．
	private String sql_date = "";
	private String sql_time = "";

	private String driver;
	private String url;
	private String user;
	private String pass;
	private String ZULIBF;
	private String ZSLIBF;

	public static void main(String[] args) {
		try {
			if (args.length < 2) {
				System.out.println(
						"Parameter error!! args.length : " + args.length +"\n" +
								"	Param1 : 入力ファイル名	\n" +
								"	Param2 : 出力ファイル名	\n" +
								"	Param3 : 設定ファイル名	\n" +
						"を指定して下さい。終了します。");
				System.exit(1);
			}
			String inputFileName  = args[0];
			String outputFileName = args[1];
			String setupFileName  = args[2];

			new getZumenForSKE1().start(inputFileName, outputFileName, setupFileName);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void start(String inputFileName, String outputFileName,String setupFileName)
			throws Exception {
		try {
			// 日時を取得
			sql_date = get_sqldate();
			sql_time = get_sqltime();
			System.out.println("= リスト作成開始 = [" + sql_date + " " + sql_time
					+ "]");

			Properties prop = new Properties(); // プロパティのインスタンス作成．
			prop.load(new FileInputStream(setupFileName));

			driver		= prop.getProperty("settuDriver");
			url			= prop.getProperty("settuDb");
			user		= prop.getProperty("settuUid");
			pass		= prop.getProperty("settuPw");
			ZULIBF 		= prop.getProperty("settuZULIBF");
			ZSLIBF		= prop.getProperty("settuZSLIBF");

			// 出力ファイル削除
			delOutputFile(outputFileName);

			// 設定ファイル読込
			// getProp(setupFileName);

			// DB接続
			connect(setupFileName);

			// プリペア文の登録
			setPrepare();

			// リスト作成
			selectSettsuNoList(inputFileName, outputFileName);

			// DB切断
			close();

			// 日時を取得
			sql_date = get_sqldate();
			sql_time = get_sqltime();
			System.out.println("= リスト作成終了 = [" + sql_date + " " + sql_time
					+ "]");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ファイル削除
	private void delOutputFile(String delete_file) throws Exception {
		try {
			boolean exst = false;
			boolean delfile = false;

			File file = new File(delete_file);
			exst = file.exists();

			if (exst == true) {
				delfile = file.delete();
			}
			System.out.println("\nファイル削除[" + delete_file + "] ⇒ [" + delfile
					+ "]\n");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// プリペア文の登録
	private void setPrepare() throws SQLException {
		StringBuffer bufSql = new StringBuffer(1028);
		try {
			// 図面設通DB用

			bufSql.delete(0, bufSql.length());
			bufSql.append("SELECT");
			bufSql.append(" TZZMBAP,");
			bufSql.append(" TZKDBAP");
			bufSql.append(" FROM " + ZULIBF + ".ZUPF24");
			bufSql.append(" WHERE");
			bufSql.append(" GZZCP = ?");
			bufSql.append(" ORDER BY TZKDBAP DESC");
			pstmt[0] = con.prepareStatement(bufSql.toString());

			bufSql.delete(0, bufSql.length());
			bufSql.append("SELECT");
			bufSql.append(" STSR,");
			bufSql.append(" DHSTBA,");
			bufSql.append(" TOYM ");
			bufSql.append(" FROM " + ZSLIBF + ".ZSPF14");
			bufSql.append(" WHERE");
			bufSql.append(" TZZMBA = ?");
			bufSql.append(" AND TZKDBA = ?");
			bufSql.append(" ORDER BY TOYM");
			pstmt[1] = con.prepareStatement(bufSql.toString());

			bufSql.delete(0, bufSql.length());
			bufSql.append("SELECT");
			bufSql.append(" KXJRDT");
			bufSql.append(" FROM " + ZSLIBF + ".ZSPF10");
			bufSql.append(" WHERE");
			bufSql.append(" STSR = ?");
			bufSql.append(" AND DHSTBA = ?");
			bufSql.append(" AND KDBA = ''");
			bufSql.append(" ORDER BY KXJRDT DESC");
			pstmt[2] = con.prepareStatement(bufSql.toString());

			bufSql.delete(0, bufSql.length());
			bufSql.append("SELECT");
			bufSql.append(" PRFGP");
			bufSql.append(" FROM " + ZULIBF + ".ZUPF23");
			bufSql.append(" WHERE");
			bufSql.append(" TZZMBAP = ?");
			bufSql.append(" AND TZKDBAP = ?");
			bufSql.append(" AND TZOVP = '0'");
			pstmt[3] = con.prepareStatement(bufSql.toString());

			bufSql.delete(0, bufSql.length());
			bufSql.append("select ");
			bufSql.append(" Las.GZZCP AS GZZCP , ");		//集合図面 図面番号
			bufSql.append(" Las.TZZMBAP AS TZZMBAP , ");	//タイトル図面 - 図面番号
			bufSql.append(" Las.TZKDBAP AS TZKDBAP , ");	//タイトル図面 - 改訂No
			bufSql.append(" Las.DHSTBA AS DHSTBA , ");		//代表設通No
			bufSql.append(" JD.KXJRDT , ");					//受領登録年月日(受領日)
			bufSql.append(" Las.PRFGP AS PRFGP , ");		//開発符号
			bufSql.append(" Las.TOYM AS TOYM , ");			//登録年月日(出図予定日?)
			bufSql.append(" Las.KDRI AS KDRI , ");			//改訂理由(件名)
			bufSql.append(" JD.STSR ");						//設通シリーズ

			bufSql.append(" FROM ZSLIBF.ZSPF10 JD ");
			bufSql.append(" INNER JOIN ");
			bufSql.append(" (select ");
			bufSql.append("  AKF.TZZMBAP AS TZZMBAP  , ");
			bufSql.append("  ECS.DHSTBA AS DHSTBA  , ");
			bufSql.append("  AKF.TZKDBAP AS TZKDBAP , ");
			bufSql.append("  AKF.PRFGP AS PRFGP , ");
			bufSql.append("  ECS.STSR AS STSR , ");
			bufSql.append("  ECS.TOYM AS TOYM , ");
			bufSql.append("  AKF.GZZCP , ");
			bufSql.append("  AKF.KDRI  ");

			bufSql.append("  FROM ZSLIBF.ZSPF14 ECS ");
			bufSql.append("  INNER JOIN ");
			bufSql.append("   (SELECT ");
			bufSql.append("    BKF.PRFGP AS PRFGP , ");
			bufSql.append("    BASE.TZZMBAP AS TZZMBAP , ");
			bufSql.append("    BASE.TZKDBAP AS TZKDBAP , ");
			bufSql.append("    BASE.GZZCP , ");
			bufSql.append("    BKF.KDRI ");
			bufSql.append("    FROM ZULIBF.ZUPF23 BKF ");
			bufSql.append("    INNER JOIN ");
			bufSql.append("    ZULIBF.ZUPF24 BASE ");
			bufSql.append("    on BKF.TZZMBAP = BASE.TZZMBAP ");
			bufSql.append("    and BKF.TZKDBAP = BASE.TZKDBAP ");
			bufSql.append("    WHERE BASE.GZZCP = ? ");
			bufSql.append("    and BKF.TZOVP = '0' ");
			bufSql.append("    order by BASE.TZKDBAP desc ) AKF ");
			bufSql.append("  on ECS.TZZMBA = AKF.TZZMBAP ");
			bufSql.append("  and ECS.TZKDBA = AKF.TZKDBAP ");
			bufSql.append("  order by ECS.TOYM DESC) Las ");
			bufSql.append(" on las.STSR = JD.STSR ");
			bufSql.append(" and JD.DHSTBA = Las.DHSTBA ");
			bufSql.append(" where JD.KDBA = '' ");
			bufSql.append(" and JD.KXJRDT <> 0 ");			
			bufSql.append(" ORDER BY Las.TOYM DESC");
			pstmt[4] = con.prepareStatement(bufSql.toString());



		} catch (SQLException e) {
			while (e != null) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.out.println("");
				e = e.getNextException();
			}
		}
	}

	private void selectSettsuNoList(String inputFileName, String outputFileName)
			throws SQLException {

		String buff = "";
		String[] inputSplit	= new String[1028];
		ResultSet rs1 = null;
		ResultSet rs2 = null;
		ResultSet rs3 = null;
		//ResultSet rs4 = null;
		ResultSet rsTest = null;
		int i = 0;
		//String KaihatsuFugo = "";

		try {
			// 入力ファイルの定義
			FileInputStream fis = new FileInputStream(inputFileName);
			InputStreamReader isr = new InputStreamReader(fis, "MS932");
			BufferedReader br = new BufferedReader(isr);

			// 出力ファイルの定義
			FileOutputStream fos = new FileOutputStream(outputFileName);
			OutputStreamWriter osw = new OutputStreamWriter(fos, "MS932");
			BufferedWriter bw = new BufferedWriter(osw);
			// 入力ファイル読込み
			while ((buff = br.readLine()) != null) {


				System.out.println("\nbuff = [" + buff + "]\n");
				inputSplit = buff.split("\t");

				// 変数格納
				//pstmt[0].setString(1, inputSplit[0].trim());
				pstmt[4].setString(1, inputSplit[0].trim());


				rsTest = pstmt[4].executeQuery();

//				if ( rsTest.next() ) {
					
/*
					s = String.format("%s\t%s\t%s\t%s\t%d\t%s\t%d\t%s\n",
							inputSplit[1].trim(), rsTest.getString("DHSTBA"), rsTest.getInt("KXJRDT"), rsTest.getString("TZKDBAP"), rsTest.getString("PRFGP"));
*/							
				while (rsTest.next()) {
					String s;
					s = String.format("%s\t%s\t%s\t%s\t%d\t%s\t%d\t%s\t%s\n",
							inputSplit[1].trim(), 
							rsTest.getString("TZZMBAP"), 
							rsTest.getString("TZKDBAP"), 
							rsTest.getString("DHSTBA"), 
							rsTest.getInt("KXJRDT"),
							rsTest.getString("PRFGP"),
							rsTest.getInt("TOYM"),
							rsTest.getString("KDRI"),
							rsTest.getString("STSR")
							);	
					bw.write(convertSJISto932(s));
					System.out.println(s);
					
				}
//				}

				rsTest.close();
			}
			// ファイルを閉じる
			br.close(); // 入力ファイル
			bw.close(); // 出力ファイル

		} catch (SQLException e) {
			while (e != null) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.out.println("");
				e = e.getNextException();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs1 != null) {
					rs1.close();
				}
				if (rs2 != null) {
					rs2.close();
				}
				if (rs3 != null) {
					rs3.close();
				}

				for (i = 0; i < pstmt.length; i++) {
					if (pstmt[i] != null) {
						pstmt[i].close();
					}
				}
			} catch (SQLException e) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.out.println("");
				e = e.getNextException();
			}
		}
	}

	// DB接続
	private void connect(String setupFileName) throws Exception {
		Driver drv = (Driver) (Class.forName(driver).newInstance());
		DriverManager.registerDriver(drv);
		con = DriverManager.getConnection(url, user, pass);
	}

	// DB切断
	private void close() throws SQLException {
		if (con != null)
			con.close();
	}

	// 年月日取得(SQL型)
	private String get_sqldate() {
		String buff = "";
		Calendar cal1 = Calendar.getInstance();
		int year = cal1.get(Calendar.YEAR);
		int month = cal1.get(Calendar.MONTH) + 1;
		int day = cal1.get(Calendar.DATE);
		buff = String.format("%04d-%02d-%02d", year, month, day);
		return (buff);
	}

	// 時分秒取得(SQL型)
	private String get_sqltime() {
		String buff = "";
		Calendar cal1 = Calendar.getInstance();
		int hour = cal1.get(Calendar.HOUR_OF_DAY);
		int minute = cal1.get(Calendar.MINUTE);
		int second = cal1.get(Calendar.SECOND);
		buff = String.format("%02d:%02d:%02d", hour, minute, second);
		return (buff);
	}

	private static String convertSJISto932(String str) {
		String out = null;
		// try {
		// byte[] sjis = str.getBytes("Shift_JIS");
		// } catch (Exception e) {
		// e.printStackTrace();
		// }

		int len = str.length();
		StringBuffer buf = new StringBuffer(len);
		/*
		 * 文字 SJISからUnicodeへのマッピング CP932からUnicodeへのマッピング ― 0x2015 0x2014 ～
		 * 0x301c 0xff5e ∥ 0x2016 0x2225 － 0x2212 0xff0d ￠ 0x00a2 0xffe0 ￡
		 * 0x00a3 0xffe1 ￢ 0x00ac 0xffe2
		 */

		for (int i = 0; i < len; i++) {
			char c = str.charAt(i);
			switch (c) {
			case '\u2015':
				c = '\u2014';
				break;
			case '\u301C':
				c = '\uFF5E';
				break;
			case '\u2016':
				c = '\u2225';
				break;
			case '\u2212':
				c = '\uFF0D';
				break;
			case '\u00A2':
				c = '\uFFE0';
				break;
			case '\u00A3':
				c = '\uFFE1';
				break;
			case '\u00AC':
				c = '\uFFE2';
				break;
			}
			buf.append(c);
		}
		out = buf.toString();
		return out;
	}
	/*
	 *絶対忘れるのでここに記載しておく
	 *ZSPF10列情報
	 *STSR			設通シリーズ
	 *RSKM			量試区分
	 *DHSTBA		代表設通No
	 *KDBA			設通改訂No
	 *WWKM			1=群馬 2=東京 3=大泉
	 *TIKMCD		G=G手配 U=U手配
	 *ALIST			BLANK=図面のみ 1=混合 2=ALISTのみ
	 *DHJSQE		関連登録者
	 *DHSNAM 		社員名
	 *DHBUCD 		部別コード
	 *DHBUNM 		部名
	 *DHBCOD 		部署コード
	 *DHBNAM 		課名
	 *DHTOYM 		代表登録年月日
	 *DHJN   		代表登録時間
	 *STTOYM 		設通作成年月日
	 *STJN   		設通作成時間
	 *HFTOYM 		配布部数自動登録
	 *HFKDBA		配布先改訂No
	 *STPAGE		最終設計通知書枚数
	 *MMPAGE		メモ白紙枚数
	 *MM			メモ白紙選択
	 *SKTBYM 		設計手離日
	 *KBH1YM 		回覧部署1確認日(原価開発)
	 *KBH2YM 		回覧部署2確認日(設計品質)
	 *KBH3YM		回覧部署3確認日(認証)
	 *UITOYM　		受付登録日
	 *UIJN   		受付登録時間
	 *HFYM   		配布年月日
	 *KXUIYM 		設計出図登録年月日
	 *KXUIJN 		設計出図登録時間
	 *KXJRDT		受領登録年月日
	 *KXRPDT		工務実施希望日
	 *KXRQYM		工務戻り登録年月日
	 *KXRQJN		工務戻り登録時間
	 *HTDATE 		配信投入日
	 *HSDATE		配信日
	 *JSDATE		受信日
	 *TOYM			登録年月日
	 *SKARYM		設計管理課 設計返却日
	 *KBH1RYM		回覧部署1 設計返却日
	 *KBH2RYM		回覧部署2 設計返却日
	 *KBH3RYM		回覧部署3 設計返却日
	 *SKAHYM		設計管理課 保留日
	 *KBH1HYM		回覧部署1 保留日
	 *KBH2HYM		回覧部署2 保留日
	 *KBH3HYM		回覧部署3 保留日
	 */
	
	/*
	 * ZSPF14列情報
	 * STSR			設通シリーズ
	 * RSKM			量子区分
	 * DHSTBA		代表設通No
	 * KDBA			設通改訂No
	 * TZZMBA		タイトル図面 - 図面番号
	 * TZKDBA		タイトル図面 - 改訂No
	 * TZOVP		タイトル図面 - オーバー
	 * TZDTKMP		タイトル図面 - データ区分
	 * TZZMCDP		タイトル図面 - 図面コード
	 * BA			No
	 * OX			正規外
	 * BKZMMU		分割数 枚数
	 * KDDP			改訂票
	 * VEVI			廃却型
	 * VIPZ			型改修
	 * VAVM			コスト変動
	 * ALIST		1 A/LIST
	 * AL_BLKNO		A/LIST ブロックNo
	 * AL_GNCOP		A/LIST 現調区分
	 * AL_REVNO		A/LIST 一連No
	 * GDATA		1 GDATA 対象
	 * MSTSR		元設通 シリーズ
	 * MRSKM		元量子区分
	 * MSTBA		元設通No
	 * MKDBA		元設通改訂No
	 * TOYM			登録年月日
	 * MGCGP		1=質量変動
	 * GNCOP		生産調達区分
	 */
	
	/*ZUPF23列情報
	 * TZZMBAP		タイトル図面 - 図面番号
	 * TZKDBA		タイトル図面 - 改訂No
	 * TZOVP		タイトル図面 - オーバー
	 * TZDTKMP		タイトル図面 - データ区分
	 * PRFGP		開発符号
	 * XXKDBAP		総合改訂No
	 * BUNMKP		カナ名称
	 * KNRNP		関連資料
	 * GNCOP		現調区分
	 * SKGIP		正規外
	 * TZZMKMP		タイトル図面 - 図面区分
	 * TZBNP		タイトル図面 - ブロック
	 * TZSIP		タイトル図面 - サイズ
	 * TZZMCDP		タイトル図面 - 図面コード
	 * JHKMP		重保区分
	 * RICDP		理由コード
	 * HYKMP		補用品区分
	 * RXMXP		リサイクルマーク
	 * BUNMP		部品名称
	 * TZSTSRP		タイトル図面 - 設通シリーズ
	 * TZSTBAP		タイトル図面 - 設通No
	 * DGTSP		製図担当者
	 * SDTSP		設計担当者
	 * DWBAP		電話番号
	 * CHKDP		点検者
	 * APVDP		承認者
	 * TZSRP		タイトル図面 - シリーズ
	 * TKYOP		適用
	 * SKDTP		作成日付
	 * FESOP		表面処理
	 * SKSOP		縮尺
	 * OLZMBAP		旧図面番号
	 * REHIP		法規制表示
	 * GKCDP		互換性コード
	 * AYZMIUP		ASSY - 図面番号01
	 * AYZMIAP		ASSY - 図面員数01
	 * AYZMIVP		ASSY - 図面番号02
	 * AYZMIBP		ASSY - 図面員数02
	 * AYZMIWP		ASSY - 図面番号03
	 * AYMICP		ASSY - 図面員数03
	 * AYZMIXP		ASSY - 図面番号04
	 * AYZMIDP		ASSY - 図面員数04
	 * TZDATEP		タイトル図面 - 更新日
	 * TZTIMEP		タイトル図面 - 更新時間
	 * CZYA			課コード
	 * JQRL			CONDITION 欄
	 * DQDTLR		3Dデータランク
	 * KDRI			改訂理由
	 * NWS3YB		納入仕様図要求 - 仕様図要求日
	 * NWDVUM		納入仕様図要求 - 3次元データの有無
	 * NWDTYB		納入仕様図要求 - データ要求日
	 * NWDTLR		納入仕様図要求 - 要求3Dデータランク
	 * NWSD			納入仕様図要求 - 設計受領日
	 * NWES			納入仕様図要求 - 設計管理課受領日
	 * JHBUCU		重保部品フラグ
	 * STSRP2		タイトル図面 - 設通シリーズ2
	 * STBAP2		タイトル図面 - 設通No2
	 * BUNKATU		分割枚数
	 */
	
	/*ZUPF24列情報
	 * TZZMBAP 	タイトル図面 - 図面番号
	 * TZKDBAP 	タイトル図面 - 改訂No
	 * TZOVP	タイトル図面 - オーバー
	 * TZDTKMP	タイトル図面 - データ区分
	 * GZCOP	集合図面 カラム
	 * GZZCP	集合図面 図面番号
	 * GZHONMP	集合図面 補助名称
	 * GZAZP	集合図面 シンボル
	 * GZDOCJP	集合図面 国内集計コード
	 * GZFOCJP	集合図面 海外集計コード
	 * GZGTCGP	集合図面 現調区分コード
	 * GZCFP	集合図面 - 注記
	 * GZMGP	集合図面 - 質量
	 * GZSRKMP	集合図面 - シリーズ
	 * TZSTSRP	タイトル図面 - 設通シリーズ
	 * TZSTBAP	タイトル図面 - 設通No
	 * OLDNOP	旧図面番号
	 * STSRP2	タイトル図面 - 設通シリーズ2
	 * STBAP2	タイトル図面 - 設通No2
	 */

}
