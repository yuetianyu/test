package main;

import java.io.*;
import java.sql.*;
import java.util.*;

public class GetPastPurchaseForSKE1 {

	// DBの接続設定
	private static Connection	conCYN			= null;
	private static Connection	conCYA			= null;
	private static Connection	conBPA			= null;
	private PreparedStatement[]	pstmt		= new PreparedStatement[5];
	

	/** フォーマット */
	static public final String FILE_DATE_PATTERN ="yyyy/MM/dd";
	/** フォーマット */
	static public final String DB2_DATE_PATTERN ="yyyyMMdd";

	static public final int cns_Cnt = 5;
	
	protected static String enCode; // ファイルエンコード．

	private String sql_date = "";
	private String sql_time = "";
	
	private ArrayList<TypKen> kens;
	private ArrayList<TypKen> results;
	private ArrayList<String> buhinNos;
	
	private int cnt = 0;
	private int cnt2 = 0;
	
	private String driverCYN;
	private String urlCYN;
	private String userCYN;
	private String passCYN;
	
	private String driverCYA;
	private String urlCYA;
	private String userCYA;
	private String passCYA;
	
	private String driverBPA;
	private String urlBPA;
	private String userBPA;
	private String passBPA;
	

	// DB接続
	private void connectCYN() throws Exception {
		/*
		Driver drv = (Driver) (Class.forName("com.ibm.as400.access.AS400JDBCDriver").newInstance());
		DriverManager.registerDriver(drv);
		con = DriverManager.getConnection("jdbc:as400://172.20.4.32/IBMAS01", "QPGMR", "QPGMR");
		*/
		Driver drv = (Driver) (Class.forName(driverCYN).newInstance());
		DriverManager.registerDriver(drv);
		conCYN = DriverManager.getConnection(urlCYN, userCYN, passCYN);
	}
	
	// DB接続
	private void connectCYA() throws Exception {
		Driver drv = (Driver) (Class.forName(driverCYA).newInstance());
		DriverManager.registerDriver(drv);
		conCYA = DriverManager.getConnection(urlCYA, userCYA, passCYA);
	}
	
	// DB接続
	private void connectBPA() throws Exception {
		try{
			Driver drv = (Driver) (Class.forName(driverBPA).newInstance());
			DriverManager.registerDriver(drv);
			conBPA = DriverManager.getConnection(urlBPA, userBPA, passBPA);
		}catch(SQLException e){
			System.err.println(e.getMessage());
			System.err.println(e.getSQLState());
			System.err.println(e.getErrorCode());
			System.out.println("");
			e = e.getNextException();
			
		}

	}

	// DB切断
	private void close() throws SQLException {
		if (conCYN != null)		conCYN.close();
		if (conCYA != null)		conCYA.close();
		if (conBPA != null)		conBPA.close();
	}

	// ファイル削除
	private void delOutputFile(String delete_file) throws Exception {
		try {
			boolean exst	= false;
			boolean delfile	= false;

			File file = new File(delete_file);
			exst = file.exists();

			if (exst == true) {
				delfile = file.delete();
			}
			System.out.println("\nファイル削除[" + delete_file + "] ⇒ [" + delfile + "]\n");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// 年月日取得(SQL型)
	private String get_sqldate() {
		String buff = "";
		Calendar cal1 = Calendar.getInstance();
		int year	= cal1.get(Calendar.YEAR);
		int month	= cal1.get(Calendar.MONTH) + 1;
		int day		= cal1.get(Calendar.DATE);
		buff = String.format("%04d-%02d-%02d", year, month, day);
		return (buff);
	}

	// 時分秒取得(SQL型)
	private String get_sqltime() {
		String buff = "";
		Calendar cal1 = Calendar.getInstance();
		int hour	= cal1.get(Calendar.HOUR_OF_DAY);
		int minute	= cal1.get(Calendar.MINUTE);
		int second	= cal1.get(Calendar.SECOND);
		buff = String.format("%02d:%02d:%02d", hour, minute, second);
		return (buff);
	}
	
	// 取得結果変換
	private static String convertSJISto932(String str) {
		String out = null;

		int len = str.length();
		StringBuffer buf = new StringBuffer(len);
		/*
 			文字 SJISからUnicodeへのマッピング CP932からUnicodeへのマッピング 
			― 0x2015 0x2014 
			～ 0x301c 0xff5e 
			∥ 0x2016 0x2225 
			－ 0x2212 0xff0d 
			￠ 0x00a2 0xffe0 
			￡ 0x00a3 0xffe1 
			￢ 0x00ac 0xffe2 
		 */

		for (int i = 0; i < len; i++) {
			char c = str.charAt(i);
			switch (c) {
			case '\u2015':	c = '\u2014';	break;
			case '\u301C':	c = '\uFF5E';	break;
			case '\u2016':	c = '\u2225';	break;
			case '\u2212':	c = '\uFF0D';	break;
			case '\u00A2':	c = '\uFFE0';	break;
			case '\u00A3':	c = '\uFFE1';	break;
			case '\u00AC':	c = '\uFFE2';	break;
			}
			buf.append(c);
		}
		out = buf.toString();
		return out;
	}

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		try {
			if (args.length < 4) {
				System.out.println(
						"Parameter error!! args.length : " + args.length +"\n" +
								"	Param1 : 入力ファイル名	\n" +
								"	Param2 : 出力ファイル名	\n" +
								"   Param3 : 設定ファイル名 \n" +
								"   Param4 : 検索条件 \n" +
						"を指定して下さい。終了します。");
				System.exit(1);
				System.exit(1);
			}
			String inputFileName	= args[0];
			String outputFileName	= args[1];
			String setupFileName 	= args[2];
			String flag = args[3];

			new GetPastPurchaseForSKE1().start(inputFileName, outputFileName, setupFileName, flag);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	//処理開始
	private void start(String inputFileName, String outputFileName, String setupFileName, String flag) throws Exception {
		try {
			// 日時を取得
			sql_date = get_sqldate();
			sql_time = get_sqltime();
			System.out.println("= リスト作成開始 = [" + sql_date + " " + sql_time + "]");
			
			//接続先情報を取得
			Properties prop = new Properties(); // プロパティのインスタンス作成．
			prop.load(new FileInputStream(setupFileName));

			
			driverCYN		= prop.getProperty("partsDriver");
			urlCYN			= prop.getProperty("partsDb");
			userCYN		= prop.getProperty("partsUid");
			passCYN		= prop.getProperty("partsPw");
			
			driverCYA		= prop.getProperty("cyaDriver");
			urlCYA			= prop.getProperty("cyaDb");
			userCYA		= prop.getProperty("cyaUid");
			passCYA		= prop.getProperty("cyaPw");
			
			driverBPA		= prop.getProperty("bpaDriver");
			urlBPA			= prop.getProperty("bpaDb");
			userBPA		= prop.getProperty("bpaUid");
			passBPA		= prop.getProperty("bpaPw");
			

			// 出力ファイル削除
			delOutputFile(outputFileName);
			
			buhinNos = new ArrayList<String>();
			results = new ArrayList<TypKen>();
			
			//ファイルから部品番号群を取得
			setBuhinNos(inputFileName);
			
			// DB接続
			connectCYN();
			connectCYA();
			connectBPA();
			
			for(String buhinNo : buhinNos){
				cnt = 0;
				cnt2 = 0;
				kens = new ArrayList<TypKen>();	//ここで初期化して部品単位で書き出す。
				
				// プリペア文の登録
				if (flag.equals("1")  || flag.equals("2")){
					setPrepare1(flag, buhinNo);
					// リスト作成
					selectData1();
				}
				
				if (flag.equals("0") || flag.equals("2")){
					// プリペア文の登録
					setPrepare2(flag, buhinNo);
					// リスト作成
					selectData2();
				}
			
				if (cnt == 0){
					// プリペア文の登録
					setPrepare3(flag, buhinNo);
					// リスト作成
					selectData3();
				}else{
					//並び替え
					//○コスト低順（検収金額昇順）（注意）この場合だけ、件数が倍になっているため
		            //（昇順）のため、後ろからチェック
					Collections.sort(kens, new KinngakuComparator());
				}
				
				//一通り終わったので外部ファイル用に展開
				int i = 0;
				for(TypKen t : kens){
					
					t.event = setEvent(t.kouji, t);
					
					
					if(i < cns_Cnt){
						if(i <= cnt-1){
							results.add(t);	
						}else{
							TypKen dummy = new TypKen();
							results.add(dummy);
						}
							
					}else{
						break;
					}
					i++;
				}
			
			}

			// DB切断
			close();

			writeOutPutFile(outputFileName);
			
			
			// 日時を取得
			sql_date = get_sqldate();
			sql_time = get_sqltime();
			System.out.println("= リスト作成終了 = [" + sql_date + " " + sql_time + "]");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	//入力ファイルを読み込んで部品の配列を作成する
	private void setBuhinNos(String inputFileName){
		String buff = "";
		String[] inputSplit	= new String[1028];
		try {
			// 入力ファイルの定義
			FileInputStream fis = new FileInputStream(inputFileName);
			InputStreamReader isr = new InputStreamReader(fis, "MS932");
			BufferedReader br = new BufferedReader(isr);

			// 入力ファイル読込み
			while ((buff = br.readLine()) != null) {
				
				System.out.println("\nbuff = [" + buff + "]\n");
				inputSplit = buff.split("\t");
				
				buhinNos.add(inputSplit[0]);	//そのまま
			}
			// ファイルを閉じる
			br.close(); // 入力ファイル

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	// プリペア文の登録
	// SQLの発行準備	
 	private void setPrepare1(String flag, String buhinNo) throws SQLException {
		StringBuffer bufSql = new StringBuffer(1028);	//実行するSQL
				StringBuffer bufSql1 = new StringBuffer(1028);	
		
		try {
			
			bufSql1.delete(0, bufSql.length());
			bufSql1.append(" SELECT  ");
			bufSql1.append(" SGISBA, KOBA, BUBA15, ");	//工事指令書ＮＯ,工事ＮＯ,部品番号
			bufSql1.append(" HAYM,   CJKSDY, ");			//発注情報　発注年月日,新調達　財務決定　検収年月日
			bufSql1.append(" WABHTA, ");					//割付情報　部品費割付予算根拠　量産単価（千円）
			bufSql1.append(" WAYOBH, ");					//割付情報　割付予算　部品費（円）
			bufSql1.append(" WAYOKH, ");					//割付情報　割付予算　型費（千円）
			bufSql1.append(" WABHKO, ");					//割付情報　部品費割付予算根拠　工法
			bufSql1.append(" MESIBH, ");					//メーカー見積値　メーカー申請値　部品費（円）
			bufSql1.append(" MESIKH, ");					//メーカー見積値　メーカー申請値　型費（千円）
			bufSql1.append(" MESIKO, ");					//メーカー見積値　メーカー申請値　工法
			bufSql1.append(" SNGTBH, ");					//審議情報　審議値　部品費（円）
			bufSql1.append(" SNGTKH, ");					//審議情報　審議値　型費（千円）
			bufSql1.append(" SNGTKO, ");					//審議情報　審議値　工法  
			bufSql1.append(" KTTAKO, ");					//決定単価　決定単価　購入単位（円）
			bufSql1.append(" KTTASI, ");					//決定単価　決定単価　支給品（円）
			bufSql1.append(" KTTANN, ");					//決定単価　決定単価　検収年月
			bufSql1.append(" BOTA10, ");					//発注情報（新調達）購入希望単価　購入希望単価　（発注単価として取得）
			bufSql1.append("  (CASE KTTAKO ");			//決定単価購入単位（円）
			bufSql1.append(" WHEN 0 THEN KTTASI ");		//決定単価支給品（円）
			bufSql1.append(" ELSE KTTAKO ");				//決定単価購入単位（円）
			bufSql1.append(" END) AS COST ");		
			bufSql1.append(" FROM CYNLIBF.CYNAA010 ");		
			bufSql1.append(" WHERE (((HCKEIT = '1') AND (((HCJYOK <> ' 取消　　 ') AND (TLYM = 0)) OR (NORU <> 0))) ");		
			bufSql1.append(" OR ((HCKEIT = '2') AND (((HCJYOK <> ' 取消　　 ') AND (TLYM = 0)) OR (NORU <> 0))) ");		
			bufSql1.append("  OR ((HCKEIT = '3') AND (((HCJYOK <> ' 取消　　 ') AND (TLYM = 0)) OR ((GNKNRK <> 0) OR (NORU <> 0)))) ");		
			bufSql1.append(" OR ((HCKEIT = '4') AND (((HCJYOK <> ' 取消　　 ') AND (TLYM = 0)) OR ((SSKNRK <> 0) OR (NORU <> 0))))) ");		
			bufSql1.append(" AND HAYM < 99991231 ");	//発注日99991231はいらない?
			
		    /*------------------------------------------------------------
		       ○検収最新順（検収日降順）○コスト低順（検収金額昇順）
		    ------------------------------------------------------------*/
			if(flag.equals("1") || flag.equals("2"))  {
				//CYNAA010購入品予算進度管理
				bufSql.delete(0, bufSql.length());
				bufSql.append(bufSql1.toString());
				bufSql.append(" AND BUBA15 = '" + buhinNo + "' ");
				
				if(flag.equals("1")){
					//○検収最新順（検収日降順）
					bufSql.append(" ORDER BY CJKSDY DESC ");	//検収日
				}else{
					//コスト＝０は除外
					bufSql.append(" AND (KTTAKO <> 0 ");	//決定単価購入単位（円）
					bufSql.append(" OR KTTASI <> 0) ");		//決定単価支給品（円）
					bufSql.append(" ORDER BY COST ASC, CJKSDY DESC ");	//検収日
				}
						
				pstmt[0] = conCYN.prepareStatement(bufSql.toString());
				System.out.println("SQL>" + bufSql.toString());
			
			}

		} catch (SQLException e) {
			while (e != null) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.err.println("");
				e = e.getNextException();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// プリペア文の登録
	// SQLの発行準備	
	private void setPrepare2(String flag, String buhinNo) throws SQLException {
		StringBuffer bufSql = new StringBuffer(1028);	//実行するSQL
		StringBuffer bufSql1 = new StringBuffer(1028);	
		
		try {

			bufSql1.delete(0, bufSql.length());
			bufSql1.append(" SELECT  ");
			bufSql1.append(" SGISBA, KOBA, BUBA15, ");	//工事指令書ＮＯ,工事ＮＯ,部品番号
			bufSql1.append(" HAYM,   CJKSDY, ");			//発注情報　発注年月日,新調達　財務決定　検収年月日
			bufSql1.append(" WABHTA, ");					//割付情報　部品費割付予算根拠　量産単価（千円）
			bufSql1.append(" WAYOBH, ");					//割付情報　割付予算　部品費（円）
			bufSql1.append(" WAYOKH, ");					//割付情報　割付予算　型費（千円）
			bufSql1.append(" WABHKO, ");					//割付情報　部品費割付予算根拠　工法
			bufSql1.append(" MESIBH, ");					//メーカー見積値　メーカー申請値　部品費（円）
			bufSql1.append(" MESIKH, ");					//メーカー見積値　メーカー申請値　型費（千円）
			bufSql1.append(" MESIKO, ");					//メーカー見積値　メーカー申請値　工法
			bufSql1.append(" SNGTBH, ");					//審議情報　審議値　部品費（円）
			bufSql1.append(" SNGTKH, ");					//審議情報　審議値　型費（千円）
			bufSql1.append(" SNGTKO, ");					//審議情報　審議値　工法  
			bufSql1.append(" KTTAKO, ");					//決定単価　決定単価　購入単位（円）
			bufSql1.append(" KTTASI, ");					//決定単価　決定単価　支給品（円）
			bufSql1.append(" KTTANN, ");					//決定単価　決定単価　検収年月
			bufSql1.append(" BOTA10, ");					//発注情報（新調達）購入希望単価　購入希望単価　（発注単価として取得）
			bufSql1.append("  (CASE KTTAKO ");			//決定単価購入単位（円）
			bufSql1.append(" WHEN 0 THEN KTTASI ");		//決定単価支給品（円）
			bufSql1.append(" ELSE KTTAKO ");				//決定単価購入単位（円）
			bufSql1.append(" END) AS COST ");		
			bufSql1.append(" FROM CYNLIBF.CYNAA010 ");		
			bufSql1.append(" WHERE (((HCKEIT = '1') AND (((HCJYOK <> ' 取消　　 ') AND (TLYM = 0)) OR (NORU <> 0))) ");		
			bufSql1.append(" OR ((HCKEIT = '2') AND (((HCJYOK <> ' 取消　　 ') AND (TLYM = 0)) OR (NORU <> 0))) ");		
			bufSql1.append("  OR ((HCKEIT = '3') AND (((HCJYOK <> ' 取消　　 ') AND (TLYM = 0)) OR ((GNKNRK <> 0) OR (NORU <> 0)))) ");		
			bufSql1.append(" OR ((HCKEIT = '4') AND (((HCJYOK <> ' 取消　　 ') AND (TLYM = 0)) OR ((SSKNRK <> 0) OR (NORU <> 0))))) ");		
			bufSql1.append(" AND HAYM < 99991231 ");	//発注日99991231はいらない?

		    /*------------------------------------------------------------
		     * ○発注最新順（発注日降順）○コスト低順（検収金額昇順
		     * ------------------------------------------------------------*/
			if(flag.equals("0")  || flag.equals("2"))  {
				//CYNAA010購入品予算進度管理
				bufSql.delete(0, bufSql.length());
				bufSql.append(bufSql1.toString());
				bufSql.append(" AND BUBA15 = '" + buhinNo + "' ");
				
				if(flag.equals("0")){
					//○発注最新順（発注日降順）
					bufSql.append(" ORDER BY HAYM DESC");	//発注年月日
				}else{
					//CYACJ010   直材実績ＤＢの「コスト」を設定するため
					//コスト＝０は除外
					bufSql.append(" AND BOTA10 <> 0 ");	//発注単価
					if(cnt > cns_Cnt){
						bufSql.append(" AND BOTA10 < " + kens.get(cnt -1).kinngaku );
					}
					
					bufSql.append(" ORDER BY BOTA10 ASC, HAYM DESC");
				}
				
			}
			
			
			pstmt[1] = conCYN.prepareStatement(bufSql.toString());
			System.out.println("SQL>" + bufSql.toString());

			

		} catch (SQLException e) {
			while (e != null) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.err.println("");
				e = e.getNextException();
			}
		} catch (Exception e) {
			e.printStackTrace();
		}

	}

	// プリペア文の登録
	// SQLの発行準備	
	private void setPrepare3(String flag, String buhinNo) throws SQLException {
		StringBuffer bufSql = new StringBuffer(1028);	//実行するSQL
		StringBuffer bufSql1 = new StringBuffer(1028);	
		bufSql.delete(0, bufSql.length());
		bufSql1.delete(0, bufSql1.length());

	    /*-----------------------------------------------------------
	     * レコードが存在しない場合
	     * ※この処理はAS03のCYACJ010の直材実績DBより取得する
	     * ------------------------------------------------------------*/
		if(cnt == 0){
			//CYACJ010   直材実績ＤＢ
			bufSql1.append(" SELECT ");
			bufSql1.append(" CJKSBA, CJKOBA, CJBUBA, ");	//工事指令書ＮＯ,工事ＮＯ,部品番号
			bufSql1.append(" CJKSDY, ");					//検収年月日
			bufSql1.append(" CJHCTA, ");					//発注単価
			bufSql1.append(" CJKTTA, ");					//決定単価
			bufSql1.append(" CJSKTA, ");					//支給単価
			bufSql1.append(" CJHCDY, ");					//発注年月日
			//決定単価>支給単価>発注単価 の順に設定
			bufSql1.append(" (CASE CJKTTA ");				//決定単価
			bufSql1.append(" WHEN 0 THEN ");				//支給単価
			bufSql1.append(" (CASE CJSKTA ");				//支給単価
			bufSql1.append(" WHEN 0 THEN CJHCTA ");			//発注単価
			bufSql1.append(" ELSE CJSKTA ");				//支給単価
			bufSql1.append(" END) ");
			bufSql1.append(" ELSE CJKTTA ");				//決定単価
			bufSql1.append(" END) AS COST ");
			bufSql1.append(" FROM CYALIBF.CYACJ010 ");
			bufSql1.append(" WHERE CJBUBA = '" + buhinNo + "' ");
			bufSql1.append(" AND CJKOKM = '41' ");	
//			bufSql1.append(" AND CJHCDY < 99991231 ");	//発注日99991231はいらない?
			
			if (flag.equals("0") || flag.equals("1")){
				//○発注最新順（発注日降順）
				//○検収最新順（検収日降順）
				bufSql1.append(" ORDER BY CJHCDY DESC ");	
				
			}else{
				//○コスト低順（検収金額昇順）
				bufSql1.append(" AND (CJHCTA > 0 ");		//
				bufSql1.append(" OR CJKTTA > 0 ");
				bufSql1.append(" OR CJSKTA > 0) ");
				bufSql1.append(" ORDER BY COST ASC, CJHCDY DESC ");
			}
			pstmt[2] = conCYA.prepareStatement(bufSql1.toString());
			System.out.println("SQL>" + bufSql1.toString());
			
		}else{
			if(flag.equals("2")){
				//○コスト低順（検収金額昇順）（注意）この場合だけ、件数が倍になっているため
	            //（昇順）のため、後ろからチェック
				Collections.sort(kens, new KinngakuComparator());
				
			}
		}
		
	}
	
	// リスト作成
	private void selectData1() throws SQLException {

		ResultSet rs		= null;
		int i				= 0;

		try {
			//SQL実行
			rs = pstmt[0].executeQuery();
			
			while ( rs.next() ) {
				cnt++;
				TypKen ken = new TypKen();
				
				ken.buhin = trimRightCharacter( rs.getString("BUBA15"));	//部品番号
				ken.kouji = rs.getString("SGISBA").trim();	//工事指令書№
				ken.kensyuu = rs.getString("CJKSDY").trim();	//検収年月日
				ken.kensyuuM = rs.getString("KTTANN").trim();	//検収年月
				
				//イベント名称は別取りしているため、ここでの処理は行わない
				ken.ryousan = rs.getDouble("WABHTA");		//量産単価
				ken.wari_buhi = rs.getDouble("WAYOBH");	//割付予算部品費（円）
				ken.wari_katahi = rs.getDouble("WAYOKH");	//割付予算型費（千円）
				ken.wari_kouhou = rs.getString("WABHKO").trim();	//割付予算工法 
				ken.mk_buhi = rs.getDouble("MESIBH");			//メーカー申請値部品費（円）
				ken.mk_katahi = rs.getDouble("MESIKH");		//メーカー申請値型費（千円）
				ken.mk_kouhou = rs.getString("MESIKO").trim();	//メーカー申請値工法
				ken.singi_buhi = rs.getDouble("SNGTBH");		//審議値部品費（円）
				ken.singi_katahi = rs.getDouble("SNGTKH");		//審議値型費（千円）
				ken.singi_kouhou = rs.getString("SNGTKO").trim();//審議値工法
				ken.hattyuu = rs.getString("HAYM").trim();	//発注年月日
				ken.kibou_hi = rs.getDouble("BOTA10");		//発注単価
				ken.sikyuu_hi = rs.getDouble("KTTAKO");	//決定単価購入単位（円）
				ken.wari_kouhou = rs.getString("KTTASI").trim();	//決定単価支給品（円）
				ken.kinngaku = rs.getDouble("COST");
//				ken.event =	setEvent(rs.getString("SGISBA"), ken);		//イベント名称取得
				
				kens.add(ken);
	            if (cnt >= cns_Cnt){
	            	   //最大表示件数いったら終了
	            	break;
	            }
							
			}
			
		} catch (SQLException e) {
			while (e != null) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.out.println("");
				e = e.getNextException();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}			

				for (i = 0; i < pstmt.length; i++) {
					if (pstmt[i] != null) {
						pstmt[i].close();
					}
				}
			} catch (SQLException e) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.out.println("");
				e = e.getNextException();
			}
		}
	}
	
	// リスト作成
	private void selectData2() throws SQLException {
		ResultSet rs		= null;
		int i				= 0;

		try {
			//SQL実行
			rs = pstmt[1].executeQuery();
			
			while ( rs.next() ) {
				cnt++;
				cnt2++;
				
				TypKen ken = new TypKen();
				
				ken.buhin = trimRightCharacter( rs.getString("BUBA15"));	//部品番号
				ken.kouji = rs.getString("SGISBA").trim();	//工事指令書№
				ken.kensyuu = rs.getString("CJKSDY").trim();	//検収年月日
				ken.kensyuuM = rs.getString("KTTANN").trim();	//検収年月
				
				//イベント名称は別取りしているため、ここでの処理は行わない
				ken.ryousan = rs.getDouble("WABHTA");		//量産単価
				ken.wari_buhi = rs.getDouble("WAYOBH");	//割付予算部品費（円）
				ken.wari_katahi = rs.getDouble("WAYOKH");	//割付予算型費（千円）
				ken.wari_kouhou = rs.getString("WABHKO").trim();	//割付予算工法 
				ken.mk_buhi = rs.getDouble("MESIBH");			//メーカー申請値部品費（円）
				ken.mk_katahi = rs.getDouble("MESIKH");		//メーカー申請値型費（千円）
				ken.mk_kouhou = rs.getString("MESIKO").trim();	//メーカー申請値工法
				ken.singi_buhi = rs.getDouble("SNGTBH");		//審議値部品費（円）
				ken.singi_katahi = rs.getDouble("SNGTKH");		//審議値型費（千円）
				ken.singi_kouhou = rs.getString("SNGTKO").trim();//審議値工法
				ken.hattyuu = rs.getString("HAYM").trim();	//発注年月日
				ken.kibou_hi = rs.getDouble("BOTA10");		//発注単価
				ken.sikyuu_hi = rs.getDouble("KTTAKO");	//決定単価購入単位（円）
				ken.wari_kouhou = rs.getString("KTTASI").trim();	//決定単価支給品（円）
				ken.kinngaku = rs.getDouble("COST");
//				ken.event = setEvent(rs.getString("SGISBA"), ken);		//イベント名称取得

				kens.add(ken);
	            if (cnt2 >= cns_Cnt){
	            	   //最大表示件数いったら終了
	            	break;
	            }
				
			}
			
		} catch (SQLException e) {
			while (e != null) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.out.println("");
				e = e.getNextException();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}			

				for (i = 0; i < pstmt.length; i++) {
					if (pstmt[i] != null) {
						pstmt[i].close();
					}
				}
			} catch (SQLException e) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.out.println("");
				e = e.getNextException();
			}
		}
	}
	
	// リスト作成
	private void selectData3() throws SQLException {
		ResultSet rs		= null;
		int i				= 0;

		try {
			//SQL実行
			rs = pstmt[2].executeQuery();
			
			while ( rs.next() ) {
				
				TypKen ken = new TypKen();
								
				ken.buhin = trimRightCharacter( rs.getString("CJBUBA"));	//部品番号
				ken.kouji = rs.getString("CJKSBA").trim();	//工事指令書№
				ken.kensyuu = "";	//検収年月日
				ken.kensyuuM = "";	//検収年月
				
				//イベント名称は別取りしているため、ここでの処理は行わない
				ken.ryousan = 0.0;		//量産単価
				ken.wari_buhi = 0.0;	//割付予算部品費（円）
				ken.wari_katahi = 0.0;	//割付予算型費（千円）
				ken.wari_kouhou = "";	//割付予算工法 
				ken.mk_buhi = 0.0;			//メーカー申請値部品費（円）
				ken.mk_katahi = 0.0;		//メーカー申請値型費（千円）
				ken.mk_kouhou = "";	//メーカー申請値工法
				ken.singi_buhi = 0.0;		//審議値部品費（円）
				ken.singi_katahi = 0.0;		//審議値型費（千円）
				ken.singi_kouhou = "";//審議値工法
				
				ken.hattyuu = rs.getString("CJHCDY").trim();	//発注年月日
				ken.kibou_hi = rs.getDouble("CJHCTA");		//発注単価
				
				ken.sikyuu_hi = rs.getDouble("CJKTTA");	//決定単価購入単位（円）
				ken.wari_kouhou = rs.getString("CJSKTA").trim();	//決定単価支給品（円）
				ken.kinngaku = rs.getDouble("COST");
//				ken.event = setEvent(rs.getString("CJKSBA"), ken);		//イベント名称取得
				
				kens.add(ken);
				cnt++;
	            if (cnt >= cns_Cnt){
	            	   //最大表示件数いったら終了
	            	break;
	            }
				
			}
			
		} catch (SQLException e) {
			while (e != null) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.out.println("");
				e = e.getNextException();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs != null) {
					rs.close();
				}			

				for (i = 0; i < pstmt.length; i++) {
					if (pstmt[i] != null) {
						pstmt[i].close();
					}
				}
			} catch (SQLException e) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.out.println("");
				e = e.getNextException();
			}
		}
	}
	
	//イベント名称取得
	private String setEvent(String kojiNo, TypKen ken){
		ResultSet rs2		= null;
		int i				= 0;
		
		String result = "";
		
		StringBuffer bufSql = new StringBuffer(1028);	//実行するSQL
		bufSql.delete(0, bufSql.length());
		bufSql.append(" SELECT ");
		bufSql.append(" EVTNM ");
		bufSql.append(" FROM BPALIBF.PAPF05  ");
		bufSql.append(" WHERE KOMZBA = '" + kojiNo.substring(0, 3) + "' ");
		
		
		try {
			//SQL実行
			//BPAだとエラーが返ってきた
			pstmt[3] = conCYN.prepareStatement(bufSql.toString());
			System.out.println("SQL>" + bufSql.toString());
			rs2 = pstmt[3].executeQuery();
		
			if(rs2.wasNull()){
				result = "";
			}else{
				
				while ( rs2.next() ) {
					result = rs2.getString("EVTNM").trim();	
					break;
				}
				
			}

		} catch (SQLException e) {
			while (e != null) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.out.println("");
				e = e.getNextException();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs2 != null) {
					rs2.close();
				}			

				for (i = 0; i < pstmt.length; i++) {
					if (pstmt[i] != null) {
						pstmt[i].close();
					}
				}
			} catch (SQLException e) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.out.println("");
				e = e.getNextException();
			}
		}
		return result;
		
	}

	//クラス
	private class TypKen {
		
		public String buhin = "";	//部品番号
		public String kouji = "";	//工事指令№
		public String event = "";	//イベント名称 
		public String hattyuu = "";	//発注日 
		public String kensyuu = "";	//検収日
		
		public Double kinngaku = 0.0;	//ｺｽﾄ判定用領域
		public Double ryousan = 0.0;	//量産単価（円）
		public Double wari_buhi = 0.0;	//割付部品費（円）
		public Double wari_katahi = 0.0;	//割付型費（千円）
		public String wari_kouhou = "";	//割付工法 
		public Double mk_buhi = 0.0;	//ﾒｰｶｰ値部品費（円）
		public Double mk_katahi = 0.0;	//ﾒｰｶｰ値型費（千円）
		public String mk_kouhou = "";	//ﾒｰｶｰ値工法 
		public Double singi_buhi = 0.0;	//審議値部品費（円）
		public Double  singi_katahi = 0.0;    //審議値型費（千円）
		public String  singi_kouhou = "";   //審議値工法 
	    public Double kibou_hi = 0.0;        //購入希望単価（円）
	    public Double kounyuu_hi = 0.0;      //購入単価（円）
	    public Double sikyuu_hi = 0.0;       //支給品（円）
	    public String kensyuuM = "";        //検収年月
    
	}

	//ソート条件クラス
	public class KinngakuComparator implements Comparator<TypKen> {

	    //比較メソッド（データクラスを比較して-1, 0, 1を返すように記述する）
	    public int compare(TypKen a, TypKen b) {
	        double no1 = a.kinngaku;
	        double no2 = b.kinngaku;

	        //こうすると降順でソートされる
	        if (no1 < no2) {
	            return 1;

	        } else if (no1 == no2) {
	            return 0;

	        } else {
	            return -1;

	        }
	    }

	}

	//結果出力
	private void writeOutPutFile(String outputFileName){
		try {

			// 出力ファイルの定義
			FileOutputStream fos = new FileOutputStream(outputFileName, true);
			OutputStreamWriter osw = new OutputStreamWriter(fos, "MS932");
			BufferedWriter bw = new BufferedWriter(osw);

			//			s = String.format("%s\t %s\t %s\t %s\t %d\t %s\t %d\t %s\t %s\n",
			
		for(TypKen t : results){
			/*NULLなら0.00にしておく*/
			if(t.ryousan.isNaN()){
				t.ryousan = 0.00;
			}
			if(t.wari_buhi.isNaN()){
				t.wari_buhi = 0.00;
			}
			
			if(t.wari_katahi.isNaN()){
				t.wari_katahi = 0.00;
			}
			if(t.mk_buhi.isNaN()){
				t.mk_buhi = 0.00;
			}
			if(t.mk_katahi.isNaN()){
				t.mk_katahi = 0.00;
			}
			if(t.singi_buhi.isNaN()){
				t.singi_buhi = 0.00;
			}
			if(t.singi_katahi.isNaN()){
				t.singi_katahi = 0.00;
			}
			if(t.kibou_hi.isNaN()){
				t.kibou_hi = 0.00;
			}
			if(t.kounyuu_hi.isNaN()){
				
				t.kounyuu_hi = 0.00;
			}
			if(t.sikyuu_hi.isNaN()){
				t.sikyuu_hi = 0.00;
			}
			
			
			String s;
			//%s\t 文字列+tab
			//%d\t 十進数+tab
			//%s\n 文字列+改行
			//%.2f n.nn +tab
			//%d\n 十進数+改行
			s = String.format("%s\t%.2f\t%.2f\t%.2f\t%s\t%.2f\t%.2f\t%s\t%.2f\t%.2f\t%s\t%.2f\t%.2f\t%.2f\t%s\t%s\t%s\t%s\n",
					t.buhin,	//部品番号
					t.ryousan,		//量産単価(円)
					t.wari_buhi,		//割付部品費
					t.wari_katahi,	//割付型費
					t.wari_kouhou,	//割付工法
					t.mk_buhi,		//メーカー部品費
					t.mk_katahi,	//メーカー型費
					t.mk_kouhou,	//メーカー工法
					t.singi_buhi,	//審議値部品費
					t.singi_katahi,	//審議値型費
					t.singi_kouhou,	//審議値工法
					t.kibou_hi,		//購入希望単価
					t.kounyuu_hi,	//購入単価
					t.sikyuu_hi,	//支給品
					t.kouji,		//工事指令№
					t.event,		//イベント名
					t.hattyuu,		//発注日
					t.kensyuu		//検収日
					);	
			bw.write(convertSJISto932(s));
			System.out.println(s);
		}
			bw.close(); // 出力ファイル

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * 引数で渡されてた文字列の右トリムを行います
	 * @param target 置換対象となる文字列
	 * @return 変換後の文字列 
	 */
	public static String trimRightCharacter (String target){
		if(target==null){
			return "";
		}
		return target.replaceAll(" +$","");
	}


	
}

