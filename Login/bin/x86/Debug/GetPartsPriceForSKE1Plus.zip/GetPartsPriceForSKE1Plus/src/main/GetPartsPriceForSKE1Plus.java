package main;

import java.sql.*;
import java.io.*;
import java.util.*;

//import com.braju.format.*;

public class GetPartsPriceForSKE1Plus {

	// DBの接続設定
	private static Connection con = null;
	private PreparedStatement[] pstmt = new PreparedStatement[2];

	protected static String enCode; // ファイルエンコード．
	private String sql_date = "";
	private String sql_time = "";

	public static void main(String[] args) {
		try {
			if (args.length < 3) {
				System.out.println(
						"Parameter error!! args.length : " + args.length +"\n" +
								"	Param1 : 入力ファイル名	\n" +
								"	Param2 : 出力ファイル名	\n" +
								"	Param3 : 設定ファイル名	\n" +
						"を指定して下さい。終了します。");
				System.exit(1);
			}
			String inputFileName  = args[0];
			String outputFileName = args[1];
			String setupFileName  = args[2];

			new GetPartsPriceForSKE1Plus().start(inputFileName, outputFileName, setupFileName);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void start(String inputFileName, String outputFileName,String setupFileName)
			throws Exception {
		try {
			// 日時を取得
			sql_date = get_sqldate();
			sql_time = get_sqltime();
			System.out.println("= リスト作成開始 = [" + sql_date + " " + sql_time
					+ "]");

			// 出力ファイル削除
			delOutputFile(outputFileName);

			// 設定ファイル読込
			// getProp(setupFileName);

			// DB接続
			connect(setupFileName);

			// プリペア文の登録
			setPrepare();

			// リスト作成
			selectSettsuNoList(inputFileName, outputFileName);

			// DB切断
			close();

			// 日時を取得
			sql_date = get_sqldate();
			sql_time = get_sqltime();
			System.out.println("= リスト作成終了 = [" + sql_date + " " + sql_time
					+ "]");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// ファイル削除
	private void delOutputFile(String delete_file) throws Exception {
		try {
			boolean exst = false;
			boolean delfile = false;

			File file = new File(delete_file);
			exst = file.exists();

			if (exst == true) {
				delfile = file.delete();
			}
			System.out.println("\nファイル削除[" + delete_file + "] ⇒ [" + delfile
					+ "]\n");

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	// プリペア文の登録
	private void setPrepare() throws SQLException {
		StringBuffer bufSql = new StringBuffer(1028);
		try {
			// パーツプライスリスト

			bufSql.delete(0, bufSql.length());
			bufSql.append("SELECT");
			bufSql.append(" KNTAN - SITAN AS PRICE, ");
			bufSql.append(" KTMK ");
			bufSql.append(" FROM BPALIBF.PARTSP");
			bufSql.append(" WHERE");
			bufSql.append(" BUBA13 = ?");
			pstmt[0] = con.prepareStatement(bufSql.toString());

			bufSql.delete(0, bufSql.length());
			bufSql.append("SELECT");
			bufSql.append(" COSTD * 100 AS PRICE, ");
			bufSql.append(" '' AS KTMK ");
			bufSql.append(" FROM BPALIBF.PARTSPG");
			bufSql.append(" WHERE");
			bufSql.append(" PNUM = ?");
			pstmt[1] = con.prepareStatement(bufSql.toString());
			
		} catch (SQLException e) {
			while (e != null) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.out.println("");
				e = e.getNextException();
			}
		}
	}

	private void selectSettsuNoList(String inputFileName, String outputFileName)
			throws SQLException {
		String s;
		String buff = "";
		String buff2 = "";
		String buff3 = "";
		String KPrice;
		String SPrice;
		String Mark;
		ResultSet rs0 = null;
		ResultSet rs1 = null;
		int i = 0;

		try {
			// 入力ファイルの定義
			FileInputStream fis = new FileInputStream(inputFileName);
			InputStreamReader isr = new InputStreamReader(fis, "MS932");
			BufferedReader br = new BufferedReader(isr);

			// 出力ファイルの定義
			FileOutputStream fos = new FileOutputStream(outputFileName);
			OutputStreamWriter osw = new OutputStreamWriter(fos, "MS932");
			BufferedWriter bw = new BufferedWriter(osw);

			// 入力ファイル読込み
			while ((buff = br.readLine()) != null) {

				System.out.println("\nbuff = [" + buff + "]\n");

				// 変数格納
				buff2 = buff.trim();
				buff3 = buff.trim();
				if (buff2.charAt(0) == '-') {
					buff2 = " " + buff2.substring(1, buff2.length());
					buff3 = buff3.substring(1, buff3.length());
				}

				pstmt[0].setString(1, buff2);
				Mark = "";
				rs0 = pstmt[0].executeQuery();
				if ( rs0.next() ) {
					KPrice = rs0.getString("PRICE");
					Mark = rs0.getString("KTMK");
				} else {
					KPrice = "";
				}
				rs0.close();
				
				// 変数格納
				pstmt[1].setString(1, buff3);

				rs1 = pstmt[1].executeQuery();
				if ( rs1.next() ) {
					SPrice = rs1.getString("PRICE");
				} else {
					SPrice = "";
				}
				rs1.close();
				
				s = String.format("%s\t%s\t%s\t%s\n",
						buff, KPrice, SPrice, Mark);
				bw.write(convertSJISto932(s));

			}
			// ファイルを閉じる
			br.close(); // 入力ファイル
			bw.close(); // 出力ファイル

		} catch (SQLException e) {
			while (e != null) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.out.println("");
				e = e.getNextException();
			}
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if (rs0 != null) {
					rs0.close();
				}
				if (rs1 != null) {
					rs1.close();
				}

				for (i = 0; i < pstmt.length; i++) {
					if (pstmt[i] != null) {
						pstmt[i].close();
					}
				}
			} catch (SQLException e) {
				System.err.println(e.getMessage());
				System.err.println(e.getSQLState());
				System.err.println(e.getErrorCode());
				System.out.println("");
				e = e.getNextException();
			}
		}
	}

	// DB接続
	private void connect(String setupFileName) throws Exception {
		String driver;
		String url;
		String user;
		String pass;
		Properties prop = new Properties(); // プロパティのインスタンス作成．
		prop.load(new FileInputStream(setupFileName));
		
		driver		= prop.getProperty("partsDriver");
		url			= prop.getProperty("partsDb");
		user		= prop.getProperty("partsUid");
		pass		= prop.getProperty("partsPw");
		
		Driver drv = (Driver) (Class.forName(driver).newInstance());
		DriverManager.registerDriver(drv);
		con = DriverManager.getConnection(url, user, pass);
	}

	// DB切断
	private void close() throws SQLException {
		if (con != null)
			con.close();
	}

	// 年月日取得(SQL型)
	private String get_sqldate() {
		String buff = "";
		Calendar cal1 = Calendar.getInstance();
		int year = cal1.get(Calendar.YEAR);
		int month = cal1.get(Calendar.MONTH) + 1;
		int day = cal1.get(Calendar.DATE);
		buff = String.format("%04d-%02d-%02d", year, month, day);
		return (buff);
	}

	// 時分秒取得(SQL型)
	private String get_sqltime() {
		String buff = "";
		Calendar cal1 = Calendar.getInstance();
		int hour = cal1.get(Calendar.HOUR_OF_DAY);
		int minute = cal1.get(Calendar.MINUTE);
		int second = cal1.get(Calendar.SECOND);
		buff = String.format("%02d:%02d:%02d", hour, minute, second);
		return (buff);
	}

	private static String convertSJISto932(String str) {
		String out = null;
		// try {
		// byte[] sjis = str.getBytes("Shift_JIS");
		// } catch (Exception e) {
		// e.printStackTrace();
		// }

		int len = str.length();
		StringBuffer buf = new StringBuffer(len);
		/*
		 * 文字 SJISからUnicodeへのマッピング CP932からUnicodeへのマッピング ― 0x2015 0x2014 ～
		 * 0x301c 0xff5e ∥ 0x2016 0x2225 － 0x2212 0xff0d ￠ 0x00a2 0xffe0 ￡
		 * 0x00a3 0xffe1 ￢ 0x00ac 0xffe2
		 */

		for (int i = 0; i < len; i++) {
			char c = str.charAt(i);
			switch (c) {
			case '\u2015':
				c = '\u2014';
				break;
			case '\u301C':
				c = '\uFF5E';
				break;
			case '\u2016':
				c = '\u2225';
				break;
			case '\u2212':
				c = '\uFF0D';
				break;
			case '\u00A2':
				c = '\uFFE0';
				break;
			case '\u00A3':
				c = '\uFFE1';
				break;
			case '\u00AC':
				c = '\uFFE2';
				break;
			}
			buf.append(c);
		}
		out = buf.toString();
		return out;
	}
}
